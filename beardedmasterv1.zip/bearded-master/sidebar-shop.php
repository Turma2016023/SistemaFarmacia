<?php if ( is_active_sidebar( 'shop' ) ) { ?>
	<aside id="sidebar-shop" class="sidebar column large-4">
		<?php dynamic_sidebar( 'shop' ); ?>
	</aside><!-- #sidebar-primary .aside -->
<?php } ?>